import { invariant } from "outvariant";
import { HttpResponse } from "msw/http";
import { isCommonAssetRequest } from "msw/utils/is-common-asset-request";
import { HttpNetworkFrame, NetworkSource, WebSocketNetworkFrame, defineNetwork } from "msw/experimental";
import { CancelableCloseEvent, CancelableMessageEvent } from "@mswjs/interceptors/WebSocket";
//#region src/fixture.ts
function defineNetworkFixture(options) {
	return defineNetwork({
		sources: [new PlaywrightNetworkSource({
			context: options.context,
			skipAssetRequests: options.skipAssetRequests ?? true
		})],
		handlers: options.handlers,
		onUnhandledFrame: options.onUnhandledFrame ?? "bypass",
		context: { quiet: true }
	});
}
/**
* @note Use a match-all RegExp with an optional group as the predicate
* for the `page.route()`/`page.unroute()` calls. Playwright treats given RegExp
* as the handler ID, which allows us to remove only those handlers introduces by us
* without carrying the reference to the handler function around.
*/
const INTERNAL_MATCH_ALL_REG_EXP = /.+(__MSW_PLAYWRIGHT_PREDICATE__)?/;
/**
* A network source that emits the HTTP requests and WebSocket connections
* routed through the given Playwright browser context.
*/
var PlaywrightNetworkSource = class extends NetworkSource {
	#options;
	constructor(options) {
		super();
		this.#options = options;
	}
	async enable() {
		const { context } = this.#options;
		await context.route(INTERNAL_MATCH_ALL_REG_EXP, this.#handleRequest.bind(this));
		await context.routeWebSocket(INTERNAL_MATCH_ALL_REG_EXP, this.#handleWebSocketConnection.bind(this));
	}
	async disable() {
		super.disable();
		const { context } = this.#options;
		await context.unroute(INTERNAL_MATCH_ALL_REG_EXP);
		await unrouteWebSocket(context, INTERNAL_MATCH_ALL_REG_EXP);
	}
	async #handleRequest(route, request) {
		const fetchRequest = new Request(request.url(), {
			method: request.method(),
			headers: new Headers(await request.allHeaders()),
			body: request.postDataBuffer()
		});
		/**
		* @note Skip common asset requests (default).
		* Playwright seems to experience performance degradation when routing all
		* requests through the matching logic below.
		* @see https://github.com/mswjs/playwright/issues/13
		*/
		if (this.#options.skipAssetRequests && isCommonAssetRequest(fetchRequest)) return safelyHandleRoute(() => route.fallback());
		const referer = request.headers().referer;
		const frame = new PlaywrightHttpNetworkFrame({
			request: fetchRequest,
			route,
			baseUrl: referer ? new URL(referer).origin : void 0
		});
		await this.queue(frame);
		/**
		* @note Perform the request as-is if nothing has handled it.
		* This happens when the network gets disabled while the request is in-flight.
		*/
		if (!frame.settled) frame.passthrough();
	}
	async #handleWebSocketConnection(route) {
		const frame = new PlaywrightWebSocketNetworkFrame({
			route,
			baseUrl: this.#getBaseUrl()
		});
		await this.queue(frame).catch((error) => {
			frame.errorWith(error);
		});
	}
	/**
	* Resolve the base URL for the WebSocket connections.
	* @note Playwright provides no means of knowing which page opened
	* the connection, so use the latest page in the browser context.
	*/
	#getBaseUrl() {
		const pages = this.#options.context.pages();
		const lastPage = pages[pages.length - 1];
		if (lastPage == null) return;
		return getPageUrl(lastPage);
	}
};
var PlaywrightHttpNetworkFrame = class extends HttpNetworkFrame {
	#route;
	#baseUrl;
	#settled;
	constructor(options) {
		super({ request: options.request });
		this.#route = options.route;
		this.#baseUrl = options.baseUrl;
		this.#settled = false;
	}
	/**
	* Whether this frame has instructed Playwright on how to handle the route.
	*/
	get settled() {
		return this.#settled;
	}
	resolve(...[handlers, onUnhandledFrame, resolutionContext]) {
		return super.resolve(handlers, onUnhandledFrame, {
			...resolutionContext,
			/**
			* @note Resolve relative handler URLs against the page
			* that has performed this request.
			*/
			baseUrl: resolutionContext?.baseUrl ?? this.#baseUrl
		});
	}
	passthrough() {
		this.#settle(() => this.#route.fallback());
	}
	respondWith(response) {
		if (response == null) return;
		if (response.status === 0) {
			this.#settle(() => this.#route.abort());
			return;
		}
		this.#settle(async () => {
			return this.#route.fulfill({
				status: response.status,
				headers: Object.fromEntries(response.headers),
				body: response.body ? Buffer.from(await response.arrayBuffer()) : void 0
			});
		});
	}
	errorWith(reason) {
		if (reason instanceof Response) return this.respondWith(reason);
		/**
		* @note Library errors, like the "error" strategy for unhandled frames,
		* must fail the request.
		*/
		if (reason instanceof Error && reason.name === "InternalError") {
			this.#settle(() => this.#route.abort());
			return;
		}
		const error = reason instanceof Error ? reason : new Error(reason?.toString() || "Request failure");
		this.respondWith(HttpResponse.json({
			name: error.name,
			message: error.message,
			stack: error.stack
		}, {
			status: 500,
			statusText: "Request Handler Error"
		}));
	}
	#settle(callback) {
		if (this.#settled) return;
		this.#settled = true;
		safelyHandleRoute(callback);
	}
};
var PlaywrightWebSocketNetworkFrame = class extends WebSocketNetworkFrame {
	#route;
	#baseUrl;
	constructor(options) {
		super({ connection: {
			client: new PlaywrightWebSocketClientConnection(options.route),
			server: new PlaywrightWebSocketServerConnection(options.route),
			info: { 
			/**
			* @note Playwright does not expose the protocols requested by the client.
			*/
protocols: [] }
		} });
		this.#route = options.route;
		this.#baseUrl = options.baseUrl;
	}
	resolve(...[handlers, onUnhandledFrame, resolutionContext]) {
		return super.resolve(handlers, onUnhandledFrame, {
			...resolutionContext,
			baseUrl: resolutionContext?.baseUrl ?? this.#baseUrl
		});
	}
	passthrough() {
		this.data.connection.server.connect();
	}
	errorWith(reason) {
		const { client } = this.data.connection;
		if (client instanceof PlaywrightWebSocketClientConnection) {
			const errorEvent = new Event("error");
			Object.defineProperty(errorEvent, "cause", {
				enumerable: true,
				configurable: false,
				value: reason
			});
			client.socket.dispatchEvent(errorEvent);
		}
		this.#route.close({
			code: 1011,
			reason: reason instanceof Error ? reason.message : void 0
		});
	}
};
var PlaywrightWebSocketClientConnection = class {
	ws;
	id;
	url;
	/**
	* @note Playwright does not expose the actual WebSocket reference.
	* Provide a plain event target instead so MSW can observe
	* the connection errors and closures.
	*/
	socket;
	#forwardedEvents;
	constructor(ws) {
		this.ws = ws;
		this.id = crypto.randomUUID();
		this.url = new URL(ws.url());
		this.socket = new EventTarget();
		this.#forwardedEvents = /* @__PURE__ */ new Set();
	}
	send(data) {
		sendWebSocketData(this.ws, data);
	}
	close(code, reason) {
		this.ws.close({
			code: code ?? 1e3,
			reason
		});
	}
	addEventListener(type, listener, options) {
		this.#forwardEvent(type);
		this.socket.addEventListener(type, listener, options);
	}
	removeEventListener(type, listener, options) {
		this.socket.removeEventListener(type, listener, options);
	}
	/**
	* Forward the given Playwright route event to the event target.
	* @note Playwright supports a single listener per event, and adding it
	* disables the default forwarding of that event to the server.
	* Only forward the events somebody is listening to.
	*/
	#forwardEvent(type) {
		if (this.#forwardedEvents.has(type)) return;
		this.#forwardedEvents.add(type);
		switch (type) {
			case "message":
				this.ws.onMessage((data) => {
					this.socket.dispatchEvent(new CancelableMessageEvent("message", { data }));
				});
				break;
			case "close": this.ws.onClose((code, reason) => {
				this.socket.dispatchEvent(new CancelableCloseEvent("close", {
					code,
					reason
				}));
			});
		}
	}
};
var PlaywrightWebSocketServerConnection = class {
	ws;
	#server;
	#target;
	#forwardedEvents;
	#bufferedData;
	constructor(ws) {
		this.ws = ws;
		this.#target = new EventTarget();
		this.#forwardedEvents = /* @__PURE__ */ new Set();
		this.#bufferedData = [];
	}
	connect() {
		this.#server = this.ws.connectToServer();
		/**
		* @note Playwright does not support event buffering.
		* Forward the events that have been listened to
		* before `connect()` was called.
		*/
		for (const type of this.#forwardedEvents) this.#forwardEvent(this.#server, type);
		for (const data of this.#bufferedData) this.send(data);
		this.#bufferedData.length = 0;
	}
	send(data) {
		if (this.#server == null) {
			this.#bufferedData.push(data);
			return;
		}
		sendWebSocketData(this.#server, data);
	}
	close(code, reason) {
		invariant(this.#server, "Failed to close connection to the actual WebSocket server: connection not established. Did you forget to call `connect()`?");
		this.#server.close({
			code,
			reason
		});
	}
	addEventListener(type, listener, options) {
		if (!this.#forwardedEvents.has(type)) {
			this.#forwardedEvents.add(type);
			if (this.#server) this.#forwardEvent(this.#server, type);
		}
		this.#target.addEventListener(type, listener, options);
	}
	removeEventListener(type, listener, options) {
		this.#target.removeEventListener(type, listener, options);
	}
	#forwardEvent(server, type) {
		switch (type) {
			case "message":
				server.onMessage((data) => {
					this.#target.dispatchEvent(new CancelableMessageEvent("message", { data }));
				});
				break;
			case "close": server.onClose((code, reason) => {
				this.#target.dispatchEvent(new CancelableCloseEvent("close", {
					code,
					reason
				}));
			});
		}
	}
};
/**
* Send the given WebSocket data via the Playwright route.
* @note Playwright only supports sending strings and buffers.
*/
function sendWebSocketData(ws, data) {
	if (typeof data === "string") {
		ws.send(data);
		return;
	}
	if (data instanceof Blob) {
		data.bytes().then((bytes) => {
			ws.send(Buffer.from(bytes));
		});
		return;
	}
	if (data instanceof ArrayBuffer) {
		ws.send(Buffer.from(data));
		return;
	}
	ws.send(Buffer.from(data.buffer, data.byteOffset, data.byteLength));
}
function getPageUrl(page) {
	const url = page.url();
	if (url === "about:blank") return;
	return decodeURI(new URL(encodeURI(url)).origin);
}
async function safelyHandleRoute(callback) {
	try {
		await callback();
	} catch (error) {
		/**
		* @note Ignore "Route is already handled!" errors.
		* Playwright has a bug where requests terminated due to navigation
		* cause your in-flight route handlers to throw. There's no means to
		* detect that scenario as both "route.handled" and "route._handlingPromise" are internal.
		* @see https://github.com/mswjs/playwright/issues/35
		*/
		if (error instanceof Error && /route is already handled/i.test(error.message)) return;
		throw error;
	}
}
/**
* Custom implementation of the missing `page.unrouteWebSocket()` to remove
* WebSocket route handlers from the page. Loosely inspired by `page.unroute()`.
*/
async function unrouteWebSocket(target, url, handler) {
	if (!("_webSocketRoutes" in target && Array.isArray(target._webSocketRoutes))) return;
	for (let i = target._webSocketRoutes.length - 1; i >= 0; i--) {
		const route = target._webSocketRoutes[i];
		if (route.url === url && (handler != null ? route.handler === handler : true)) target._webSocketRoutes.splice(i, 1);
	}
}
//#endregion
export { PlaywrightNetworkSource, defineNetworkFixture };
